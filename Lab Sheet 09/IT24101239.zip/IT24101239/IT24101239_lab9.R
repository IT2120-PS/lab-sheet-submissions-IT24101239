setwd("C:\\Users\\USER\\Desktop\\IT24101239")


#i
y <- rnorm(25, mean = 45, sd = 2)
print(y)



#ii
t.test(y, mu = 46, alternative = "less")
