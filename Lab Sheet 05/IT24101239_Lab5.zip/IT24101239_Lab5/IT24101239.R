getwd()
setwd("C:\\Users\\it24101239\\Desktop\\IT24101239_Lab5")
getwd()

#1
Delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE)

Delivery_Times$Delivery_Time_.minutes. <- as.numeric(Delivery_Times$Delivery_Time_.minutes.)

#2
hist(Delivery_Times$Delivery_Time_.minutes.,
     breaks = seq(20, 70, by = 5),
     right = TRUE,
     col = "lightblue",
     main = "Histogram of Delivery Times",
     xlab = "Delivery Time",
     ylab = "Frequency")

#3
#A slightly right-skewed distribution,
#In the range of 30–50 minutes distribution show a higher frequency of delivery times .
#There are fewer observations above 60 minutes.
#Data range is from 20-70.

#4

cf <- cumsum(table(cut(Delivery_Times$Delivery_Time_.minutes., breaks = seq(20, 70, by = 5), right = TRUE)))

plot(seq(22.5, 67.5, by = 5), cf, type = "o", col = "blue",
     xlab = "Delivery Time", ylab = "Cumulative Frequency",
     main = "Cumulative Frequency Polygon (Ogive)")

